<?php $__env->startSection('title', 'Stok'); ?>
<?php $__env->startSection('content'); ?><div class="row" style="justify-content:space-between">
        <h1>Histori Stok</h1>
        <a class="btn" href="<?php echo e(route('admin.stock.create')); ?>">Barang Masuk</a>
    </div>
    <div class="card">
        <form class="row" method="GET">
            <label>Produk<select name="product_id">
                    <option value="">Semua</option>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($product->id); ?>" <?php if(request('product_id') == $product->id): echo 'selected'; endif; ?>><?php echo e($product->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </label>
            <label>Tipe<select name="type">
                    <option value="">Semua</option>
                    <option value="IN">IN</option>
                    <option value="OUT">OUT</option>
                </select>
            </label>
            <button class="btn">Filter</button>
        </form>
    </div>
    <div class="card">
        <div class="table-scroll">
            <table>
                <tr>
                    <th>Waktu</th>
                    <th>Produk</th>
                    <th>Tipe</th>
                    <th>Qty</th>
                    <th>Referensi</th>
                    <th>User</th>
                </tr>
                <?php $__currentLoopData = $movements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($movement->movement_at->format('d-m-Y H:i')); ?></td>
                        <td><?php echo e($movement->product->name); ?></td>
                        <td><?php echo e($movement->type); ?></td>
                        <td><?php echo e($movement->quantity); ?></td>
                        <td><?php echo e($movement->reference); ?></td>
                        <td><?php echo e($movement->user?->name); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div><?php echo e($movements->links()); ?>

</div><?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-online-sales\resources\views/admin/stock/index.blade.php ENDPATH**/ ?>