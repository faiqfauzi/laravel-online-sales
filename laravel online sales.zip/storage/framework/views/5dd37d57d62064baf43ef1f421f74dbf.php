
<?php $__env->startSection('title', 'Daftar'); ?>
<?php $__env->startSection('content'); ?><div class="card auth-card"><span class="eyebrow">MULAI DARI SINI</span>
        <h1>Buat akun belanja</h1>
        <form method="POST" action="<?php echo e(route('register.store')); ?>"><?php echo csrf_field(); ?><label>Nama lengkap<input name="name"
                    value="<?php echo e(old('name')); ?>" maxlength="120" autocomplete="name" required></label><label>Email<input
                    type="email" name="email" value="<?php echo e(old('email')); ?>" autocomplete="username"
                    required></label><label>Password<input type="password" name="password" minlength="8"
                    autocomplete="new-password" required><span class="muted">Minimal 8
                    karakter.</span></label><label>Ulangi password<input type="password" name="password_confirmation"
                    autocomplete="new-password" required></label><button class="btn">Buat Akun</button></form>
        <p class="muted" style="margin-top:20px">Sudah punya akun? <a
                href="<?php echo e(route('login')); ?>"><strong>Masuk</strong></a></p>
</div><?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-online-sales\resources\views/auth/register.blade.php ENDPATH**/ ?>