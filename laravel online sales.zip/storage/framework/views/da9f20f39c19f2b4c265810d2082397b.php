<?php if($paginator->hasPages()): ?>
    <nav class="pagination" aria-label="Halaman katalog">
        <?php if($paginator->onFirstPage()): ?>
        <span aria-disabled="true">← Sebelumnya</span><?php else: ?><a href="<?php echo e($paginator->previousPageUrl()); ?>"
                rel="prev">← Sebelumnya</a>
        <?php endif; ?>
        <span class="active">
            <?php echo e($paginator->currentPage()); ?> / <?php echo e($paginator->lastPage()); ?></span>
        <?php if($paginator->hasMorePages()): ?>
        <a href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next">Berikutnya →</a><?php else: ?><span
                aria-disabled="true">Berikutnya →</span>
        <?php endif; ?>
    </nav>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\laravel-online-sales\resources\views/pagination/default.blade.php ENDPATH**/ ?>