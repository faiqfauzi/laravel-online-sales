
<?php $__env->startSection('title', $order->code); ?>
<?php $__env->startSection('content'); ?><h1>
        <?php echo e($order->code); ?></h1>
    <div class="grid">
        <div class="card">
            <h3>Pelanggan</h3>
            <p><?php echo e($order->user->name); ?><br><?php echo e($order->recipient_name); ?><br><?php echo e($order->phone); ?></p>
            <p><?php echo e($order->address); ?></p>
        </div>
        <div class="card">
            <h3>Pengiriman</h3>
            <p><?php echo e($order->shipping_courier); ?> - <?php echo e($order->shipping_service); ?><br><?php echo e($order->shipping_eta); ?></p>
            <p>Status: <strong><?php echo e(strtoupper($order->status)); ?></strong>
            </p>
        </div>
    </div>
    <div class="card">
        <div class="table-scroll">
            <table>
                <tr>
                    <th>Produk</th>
                    <th>Harga</th>
                    <th>Qty</th>
                    <th>Subtotal</th>
                </tr>
                <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->product_name); ?></td>
                        <td>Rp<?php echo e(number_format($item->price, 2, ',', '.')); ?></td>
                        <td><?php echo e($item->quantity); ?></td>
                        <td>Rp<?php echo e(number_format($item->subtotal, 2, ',', '.')); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
        <p>Subtotal: Rp<?php echo e(number_format($order->subtotal, 2, ',', '.')); ?></p>
        <p>Ongkir: Rp<?php echo e(number_format($order->shipping_cost, 2, ',', '.')); ?></p>
        <h3>Total: Rp<?php echo e(number_format($order->grand_total, 2, ',', '.')); ?></h3>
    </div>
    <div class="card">
        <h3>Aksi Admin</h3>
        <?php if($order->status === 'pending'): ?>
            <form style="display:inline" method="POST" action="<?php echo e(route('admin.orders.confirm', $order)); ?>"><?php echo csrf_field(); ?>
                <?php echo method_field('PATCH'); ?><button class="btn">Validasi Pesanan</button>
            </form>
            <?php endif; ?> <?php if(in_array($order->status, ['pending', 'confirmed'])): ?>
                <form style="display:inline" data-confirm="Batalkan pesanan dan kembalikan stok?" method="POST"
                    action="<?php echo e(route('admin.orders.cancel', $order)); ?>"><?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?><button
                        class="btn btn-danger">Batalkan &
                        Kembalikan Stok</button>
                </form>
                <?php endif; ?> <?php if(in_array($order->status, ['confirmed', 'processed', 'shipped'])): ?>
                    <form class="row" method="POST" action="<?php echo e(route('admin.orders.status', $order)); ?>"><?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?><select name="status">
                            <?php if($order->status === 'confirmed'): ?>
                                <option value="processed">Processed</option>
                            <?php elseif($order->status === 'processed'): ?>
                                <option value="shipped">Shipped</option>
                            <?php elseif($order->status === 'shipped'): ?>
                                <option value="completed">Completed</option>
                            <?php endif; ?>
                        </select>
                        <button class="btn">Update Status</button>
                    </form>
                <?php endif; ?>
</div><?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-online-sales\resources\views/admin/orders/show.blade.php ENDPATH**/ ?>