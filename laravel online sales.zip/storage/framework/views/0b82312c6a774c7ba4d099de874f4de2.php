
<?php $__env->startSection('title', 'Edit Produk'); ?>
<?php $__env->startSection('content'); ?><h1>Edit Produk</h1>
    <div class="card">
        <form method="POST" enctype="multipart/form-data" action="<?php echo e(route('admin.products.update', $product)); ?>"><?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?> <?php echo $__env->make('admin.products._form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></form>
</div><?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-online-sales\resources\views/admin/products/edit.blade.php ENDPATH**/ ?>