<?php $__env->startSection('title', 'Pilihan untuk keseharian'); ?>
<?php $__env->startSection('content'); ?>
    <section class="hero">
        <div><span class="eyebrow">PILIHAN UNTUK KESEHARIAN</span>
            <h1>Hal kecil yang bikin<br>harimu lebih nyaman.</h1>
            <p>Temukan kebutuhan rumah, aksesori, dan elektronik pilihan. Harga jelas, stok tersedia, siap menemani
                aktivitasmu.</p>
            <div class="hero-bottom"><span>Informasi stok langsung</span><span>Pilihan ekspedisi</span><span>Riwayat pesanan
                    lengkap</span></div>
        </div>
        <div class="hero-art" aria-hidden="true">⌨ ◉</div>
    </section>
    <div class="section-heading">
        <h2>Temukan pilihanmu</h2><span class="muted"><?php echo e($products->total()); ?> produk ditemukan</span>
    </div>
    <div class="card filters">
        <form method="GET">
            <div class="row"><label style="flex:2">Cari produk<input name="q" value="<?php echo e(request('q')); ?>"
                        placeholder="Nama produk atau SKU"></label><label>Kategori<select name="category">
                        <option value="">Semua kategori</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>" <?php if(request('category') == $category->id): echo 'selected'; endif; ?>><?php echo e($category->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </label><label>Urutkan<select name="sort">
                        <option value="">Terbaru</option>
                        <?php $__currentLoopData = ['price_asc' => 'Harga termurah', 'price_desc' => 'Harga termahal', 'name' => 'Nama A–Z']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value); ?>" <?php if(request('sort') === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </label></div>
            <div class="row"><label>Harga minimum<input type="number" min="0" step="0.01" name="min_price"
                        value="<?php echo e(request('min_price')); ?>" placeholder="Rp 0"></label><label>Harga maksimum<input
                        type="number" min="0" step="0.01" name="max_price" value="<?php echo e(request('max_price')); ?>"
                        placeholder="Tanpa batas"></label><label><input type="checkbox" name="ready" value="1"
                        <?php if(request('ready')): echo 'checked'; endif; ?>>Stok tersedia</label>
                <div class="filter-actions"><button class="btn">Terapkan Filter</button><a class="search-reset"
                        href="<?php echo e(route('shop.index')); ?>">Reset</a></div>
            </div>
        </form>
    </div>
    <div class="grid product-grid">
        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <article class="card product-card"><a href="<?php echo e(route('shop.show', $product->slug)); ?>">
                    <?php if($product->image): ?>
                        <img class="thumb" src="<?php echo e(asset('storage/' . $product->image)); ?>" alt="<?php echo e($product->name); ?>"
                        loading="lazy"><?php else: ?><div class="thumb product-placeholder" aria-hidden="true">□</div>
                    <?php endif; ?>
                </a>
                <div class="product-info"><span class="muted"><?php echo e($product->category->name); ?></span>
                    <h3><a href="<?php echo e(route('shop.show', $product->slug)); ?>"><?php echo e($product->name); ?></a></h3>
                    <p class="price">Rp<?php echo e(number_format($product->price, 2, ',', '.')); ?></p>
                    <p class="stock <?php echo e($product->stock === 0 ? 'empty' : ''); ?>">
                        <?php echo e($product->stock > 0 ? $product->stock . ' tersedia' : 'Stok habis'); ?></p><a class="btn btn-light"
                        href="<?php echo e(route('shop.show', $product->slug)); ?>">Lihat Produk ↗</a>
                </div>
        </article><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><div class="empty-state">
                <h3>Belum ada produk yang cocok</h3>
                <p class="muted">Coba kata kunci lain atau reset filter pencarian.</p><a class="btn-light"
                    href="<?php echo e(route('shop.index')); ?>">Lihat semua produk</a>
            </div>
        <?php endif; ?>
    </div><?php echo e($products->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-online-sales\resources\views/shop/index.blade.php ENDPATH**/ ?>