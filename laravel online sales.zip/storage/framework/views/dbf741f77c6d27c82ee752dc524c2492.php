<?php $__env->startSection('title', 'Transaksi'); ?>
<?php $__env->startSection('content'); ?><h1>
        Transaksi</h1>
    <div class="card">
        <form class="row" method="GET">
            <input class="input" style="max-width:280px" name="q" value="<?php echo e(request('q')); ?>"
                placeholder="Kode / pelanggan">
            <select name="status">
                <option value="">Semua status</option>
                <?php $__currentLoopData = ['pending', 'confirmed', 'processed', 'shipped', 'completed', 'cancelled']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($status); ?>" <?php if(request('status') === $status): echo 'selected'; endif; ?>><?php echo e(ucfirst($status)); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <button class="btn">Filter</button>
        </form>
    </div>
    <div class="card">
        <div class="table-scroll">
            <table>
                <tr>
                    <th>Kode</th>
                    <th>Pelanggan</th>
                    <th>Tanggal</th>
                    <th>Total</th>
                    <th>Status</th>
                    <th>
                    </th>
                </tr>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($order->code); ?></td>
                        <td><?php echo e($order->user->name); ?></td>
                        <td><?php echo e($order->ordered_at->format('d-m-Y H:i')); ?></td>
                        <td>Rp<?php echo e(number_format($order->grand_total, 2, ',', '.')); ?></td>
                        <td><?php echo e(strtoupper($order->status)); ?></td>
                        <td>
                            <a href="<?php echo e(route('admin.orders.show', $order)); ?>">Detail</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div><?php echo e($orders->links()); ?>

</div><?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-online-sales\resources\views/admin/orders/index.blade.php ENDPATH**/ ?>