<?php $__env->startSection('title', 'Dashboard Admin'); ?>
<?php $__env->startSection('content'); ?><h1>
        Dashboard</h1>
    <div class="grid">
        <div class="card">
            <strong><?php echo e($productCount); ?></strong>
            <br>Produk
        </div>
        <div class="card">
            <strong><?php echo e($lowStockCount); ?></strong>
            <br>Stok <= 5</div>
                <div class="card">
                    <strong><?php echo e($pendingOrderCount); ?></strong>
                    <br>Pesanan Pending
                </div>
                <div class="card">
                    <strong>Rp<?php echo e(number_format($todaySales, 2, ',', '.')); ?></strong>
                    <br>Penjualan Hari Ini
                </div>
        </div>
        <div class="card">
            <h3>Transaksi Terbaru</h3>
            <div class="table-scroll">
                <table>
                    <tr>
                        <th>Kode</th>
                        <th>Pelanggan</th>
                        <th>Total</th>
                        <th>Status</th>
                    </tr>
                    <?php $__currentLoopData = $latestOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($order->code); ?></td>
                            <td><?php echo e($order->user->name); ?></td>
                            <td>Rp<?php echo e(number_format($order->grand_total, 2, ',', '.')); ?></td>
                            <td><?php echo e($order->status); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
    </div><?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-online-sales\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>