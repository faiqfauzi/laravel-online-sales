<?php $__env->startSection('title', 'Halaman Toko'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <h1>Halaman Toko Sementara</h1>
        <p>
            Selamat datang di aplikasi penjualan online.
            Halaman katalog produk akan dibuat pada Milestone 4.
        </p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-online-sales\resources\views/shop/placeholder.blade.php ENDPATH**/ ?>