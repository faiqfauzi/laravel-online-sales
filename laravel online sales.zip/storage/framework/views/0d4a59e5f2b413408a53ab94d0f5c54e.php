<?php $__env->startSection('title', 'Keranjang'); ?>
<?php $__env->startSection('content'); ?><h1>
        Keranjang</h1>
    <?php if($items->isEmpty()): ?>
        <div class="card">Keranjang kosong. <a href="<?php echo e(route('shop.index')); ?>">Belanja sekarang.</a>
    </div><?php else: ?><div class="table-scroll">
            <table>
                <thead>
                    <tr>
                        <th>Produk</th>
                        <th>Harga</th>
                        <th>Jumlah</th>
                        <th>Subtotal</th>
                        <th>
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item['product']->name); ?></td>
                            <td>Rp<?php echo e(number_format($item['product']->price, 2, ',', '.')); ?></td>
                            <td>
                                <form method="POST" action="<?php echo e(route('cart.update', $item['product'])); ?>"><?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?><input style="width:70px" type="number" name="quantity" min="1"
                                        max="<?php echo e($item['product']->stock); ?>" value="<?php echo e($item['quantity']); ?>">
                                    <button>Update</button>
                                </form>
                            </td>
                            <td>Rp<?php echo e(number_format($item['lineTotal'], 2, ',', '.')); ?></td>
                            <td>
                                <form method="POST" action="<?php echo e(route('cart.destroy', $item['product'])); ?>"><?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?><button>Hapus</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="card" style="margin-top:18px">
            <h3>Subtotal: Rp<?php echo e(number_format($subtotal, 2, ',', '.')); ?></h3>
            <?php if(Route::has('checkout.index')): ?>
                <a class="btn" href="<?php echo e(route('checkout.index')); ?>">Lanjut Checkout</a>
            <?php endif; ?>

        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-online-sales\resources\views/cart/index.blade.php ENDPATH**/ ?>