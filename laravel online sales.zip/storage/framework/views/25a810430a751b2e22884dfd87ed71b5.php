
<?php $__env->startSection('title', 'Barang Masuk'); ?>
<?php $__env->startSection('content'); ?><h1>
        Barang Masuk / Penyetokan</h1>
    <div class="card">
        <form method="POST" action="<?php echo e(route('admin.stock.store')); ?>"><?php echo csrf_field(); ?><label>Produk<select name="product_id" required>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($product->id); ?>"><?php echo e($product->sku); ?> - <?php echo e($product->name); ?>

                            (stok <?php echo e($product->stock); ?>)
                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </label>
            <label>Jumlah<input class="input" type="number" min="1" name="quantity" required>
            </label>
            <label>Harga Beli per Unit<input class="input" type="number" min="0" step="0.01" name="unit_cost">
            </label>
            <label>Referensi / No. Faktur<input class="input" name="reference">
            </label>
            <label>Tanggal Masuk<input class="input" type="datetime-local" name="movement_at"
                    value="<?php echo e(now()->format('Y-m-d\TH:i')); ?>" required>
            </label>
            <label>Catatan
                <textarea class="input" name="note">
</textarea>
            </label>
            <button class="btn">Simpan Barang Masuk</button>
        </form>
</div><?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-online-sales\resources\views/admin/stock/create.blade.php ENDPATH**/ ?>