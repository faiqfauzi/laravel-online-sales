<?php $__env->startSection('title', 'Ekspedisi'); ?>
<?php $__env->startSection('content'); ?><h1>
        Layanan Ekspedisi</h1>
    <div class="card">
        <form method="POST" action="<?php echo e(route('admin.shipping.store')); ?>"><?php echo csrf_field(); ?><div class="row">
                <label>Kurir<input class="input" name="courier" required>
                </label>
                <label>Layanan<input class="input" name="service" required>
                </label>
                <label>Estimasi<input class="input" name="eta">
                </label>
                <label>Biaya<input class="input" type="number" step="0.01" name="cost" min="0" required>
                </label>
                <label>
                    <input type="checkbox" name="is_active" value="1" checked> Aktif</label>
                <button class="btn">Tambah</button>
            </div>
        </form>
    </div>
    <div class="card">
        <div class="table-scroll">
            <table>
                <tr>
                    <th>Kurir</th>
                    <th>Layanan</th>
                    <th>ETA</th>
                    <th>Biaya</th>
                    <th>Status</th>
                    <th>
                    </th>
                </tr>
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($service->courier); ?></td>
                        <td><?php echo e($service->service); ?></td>
                        <td><?php echo e($service->eta); ?></td>
                        <td>Rp<?php echo e(number_format($service->cost, 2, ',', '.')); ?></td>
                        <td><?php echo e($service->is_active ? 'Aktif' : 'Nonaktif'); ?></td>
                        <td>
                            <details>
                                <summary>Ubah layanan</summary>
                                <form style="display:block;min-width:260px" method="POST"
                                    action="<?php echo e(route('admin.shipping.update', $service)); ?>"><?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                                    <label>Kurir<input name="courier" value="<?php echo e($service->courier); ?>"
                                            required></label><label>Layanan<input name="service"
                                            value="<?php echo e($service->service); ?>" required></label><label>Estimasi<input
                                            name="eta" value="<?php echo e($service->eta); ?>"></label><label>Biaya<input
                                            name="cost" type="number" min="0" step="0.01"
                                            value="<?php echo e($service->cost); ?>" required></label><label><input type="checkbox"
                                            name="is_active" value="1"
                                            <?php if($service->is_active): echo 'checked'; endif; ?>>Aktif</label><button class="btn">Simpan
                                        Perubahan</button>
                                </form>
                            </details>
                            <form method="POST" action="<?php echo e(route('admin.shipping.destroy', $service)); ?>"><?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?><button class="btn
btn-danger">Nonaktifkan</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
</div><?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-online-sales\resources\views/admin/shipping/index.blade.php ENDPATH**/ ?>