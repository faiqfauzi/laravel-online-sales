<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title><?php echo $__env->yieldContent('title', 'Dashboard'); ?> · Admin Ruang Belanja</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/store.css')); ?>">
</head>

<body>
    <div class="admin-wrap">
        <aside class="admin-side"><a class="brand" href="<?php echo e(route('admin.dashboard')); ?>">ruangbelanja.</a>
            <div class="eyebrow">Ruang Pengelola</div>
            <?php $__currentLoopData = [['admin.dashboard', 'Ringkasan'], ['admin.categories.index', 'Kategori'], ['admin.products.index', 'Produk'], ['admin.stock.index', 'Stok & Barang Masuk'], ['admin.shipping.index', 'Ekspedisi'], ['admin.orders.index', 'Transaksi']]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$route, $label]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(Route::has($route)): ?>
                    <a href="<?php echo e(route($route)); ?>"
                        <?php if(request()->routeIs($route === 'admin.dashboard' ? $route : str_replace('.index', '.*', $route))): ?> aria-current="page" <?php endif; ?>><?php echo e($label); ?></a>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('shop.index')); ?>">↗ Lihat Toko</a>
            <form method="POST" action="<?php echo e(route('logout')); ?>"><?php echo csrf_field(); ?><button class="btn-light">Keluar</button></form>
        </aside>
        <main class="admin-main">
            <div class="admin-context"><span>Administrasi / <?php echo $__env->yieldContent('title', 'Dashboard'); ?></span><span><?php echo e(auth()->user()->name); ?> ·
                    Admin</span></div><?php echo $__env->make('layouts.flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?> <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
    <script src="<?php echo e(asset('js/store.js')); ?>" defer></script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\laravel-online-sales\resources\views/layouts/admin.blade.php ENDPATH**/ ?>