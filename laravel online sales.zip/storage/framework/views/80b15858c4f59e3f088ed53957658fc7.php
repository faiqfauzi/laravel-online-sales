<label>
    Kategori<select name="category_id" required>
        <option value="">Pilih</option>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($category->id); ?>" <?php if(old('category_id', $product->category_id ?? null) == $category->id): echo 'selected'; endif; ?>><?php echo e($category->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</label>
<label>SKU<input class="input" name="sku" value="<?php echo e(old('sku', $product->sku ?? '')); ?>" required>
</label>
<label>Nama Produk<input class="input" name="name" value="<?php echo e(old('name', $product->name ?? '')); ?>" required>
</label>
<label>Deskripsi
    <textarea class="input" rows="5" name="description"><?php echo e(old('description', $product->description ?? '')); ?></textarea>
</label>
<label>Harga<input class="input" type="number" min="0" step="0.01" name="price"
        value="<?php echo e(old('price', $product->price ?? 0)); ?>" required>
</label>
<label>Gambar<input class="input" type="file" name="image" accept="image/*">
</label>
<label>
    <input type="checkbox" name="is_active" value="1" <?php if(old('is_active', $product->is_active ?? true)): echo 'checked'; endif; ?>> Aktif</label>
<button class="btn">Simpan</button>
<?php /**PATH C:\xampp\htdocs\laravel-online-sales\resources\views/admin/products/_form.blade.php ENDPATH**/ ?>