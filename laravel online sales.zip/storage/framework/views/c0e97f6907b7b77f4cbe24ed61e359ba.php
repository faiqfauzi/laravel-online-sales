<?php $__env->startSection('title', 'Kategori'); ?>
<?php $__env->startSection('content'); ?><h1>
        Kategori</h1>
    <div class="card">
        <form method="POST" action="<?php echo e(route('admin.categories.store')); ?>"><?php echo csrf_field(); ?><label>Nama Kategori<input class="input"
                    name="name" required>
            </label>
            <button class="btn">Tambah</button>
        </form>
    </div>
    <div class="card">
        <div class="table-scroll">
            <table>
                <tr>
                    <th>Nama</th>
                    <th>Jumlah Produk</th>
                    <th>Aksi</th>
                </tr>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <form class="row" method="POST" action="<?php echo e(route('admin.categories.update', $category)); ?>">
                                <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?><input class="input" style="max-width:240px" name="name"
                                    value="<?php echo e($category->name); ?>">
                                <button class="btn">Simpan</button>
                            </form>
                        </td>
                        <td><?php echo e($category->products_count); ?></td>
                        <td>
                            <form method="POST" action="<?php echo e(route('admin.categories.destroy', $category)); ?>"><?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?><button class="btn btn-danger">Hapus</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
</div><?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-online-sales\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>