<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta name="description"
        content="Belanja kebutuhan sehari-hari dengan pilihan produk, stok yang jelas, dan pengiriman yang mudah.">
    <title><?php echo $__env->yieldContent('title', 'Katalog'); ?> · Ruang Belanja</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/store.css')); ?>">
</head>

<body>
    <div class="top-note">Pilihan sederhana. Belanja lebih nyaman.</div>
    <header class="site-header">
        <nav class="container nav" aria-label="Navigasi utama">
            <a class="brand" href="<?php echo e(route('shop.index')); ?>">
                <span class="brand-mark" aria-hidden="true">↗</span>ruangbelanja<span
                    style="color:#7aa487">.</span></a><a href="<?php echo e(route('shop.index')); ?>"
                <?php if(request()->routeIs('shop.*')): ?> aria-current="page" <?php endif; ?>>Jelajahi Produk</a>
            <?php if(auth()->guard()->check()): ?> <?php if(auth()->user()->role === 'customer'): ?>
                <?php if(Route::has('cart.index')): ?>
                    <a href="<?php echo e(route('cart.index')); ?>"
                        <?php if(request()->routeIs('cart.*')): ?> aria-current="page" <?php endif; ?>>Keranjang
                        (<?php echo e(array_sum(session('cart', []))); ?>)</a>
                <?php endif; ?>
                <?php if(Route::has('orders.index')): ?>
                    <a href="<?php echo e(route('orders.index')); ?>"
                        <?php if(request()->routeIs('orders.*')): ?> aria-current="page" <?php endif; ?>>Pesanan</a>
                <?php endif; ?>
            <?php else: ?><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard Admin</a>
            <?php endif; ?>
            <span class="account">
                Halo, <?php echo e(auth()->user()->name); ?></span>
            <form method="POST" action="<?php echo e(route('logout')); ?>"><?php echo csrf_field(); ?><button class="btn-light">Keluar</button></form>
        <?php else: ?><a href="<?php echo e(route('login')); ?>">Masuk</a><a class="btn"
            href="<?php echo e(route('register')); ?>">Daftar</a><?php endif; ?>
    </nav>
</header>
<main class="container"><?php echo $__env->make('layouts.flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?> <?php echo $__env->yieldContent('content'); ?></main>
<footer class="container footer"><strong>ruangbelanja.</strong>
    <span>Proyek praktikum Laravel · Admin & Pelanggan</span>
    <span>Belanja dengan informasi yang jelas.</span>
</footer>
<script src="<?php echo e(asset('js/store.js')); ?>" defer></script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\laravel online sales\resources\views/layouts/app.blade.php ENDPATH**/ ?>