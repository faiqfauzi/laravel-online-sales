<?php $__env->startSection('title', 'Produk'); ?>
<?php $__env->startSection('content'); ?><div class="row" style="justify-content:space-between">
        <h1>Produk</h1>
        <a class="btn" href="<?php echo e(route('admin.products.create')); ?>">Tambah Produk</a>
    </div>
    <div class="card">
        <form method="GET" class="row">
            <input class="input" style="max-width:320px" name="q" value="<?php echo e(request('q')); ?>"
                placeholder="Cari nama/SKU">
            <button class="btn">Cari</button>
        </form>
    </div>
    <div class="card">
        <div class="table-scroll">
            <table>
                <tr>
                    <th>SKU</th>
                    <th>Produk</th>
                    <th>Kategori</th>
                    <th>Harga</th>
                    <th>Stok</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($product->sku); ?></td>
                        <td><?php echo e($product->name); ?></td>
                        <td><?php echo e($product->category->name); ?></td>
                        <td>Rp<?php echo e(number_format($product->price, 2, ',', '.')); ?></td>
                        <td><?php echo e($product->stock); ?></td>
                        <td><?php echo e($product->is_active ? 'Aktif' : 'Nonaktif'); ?></td>
                        <td class="row">
                            <a class="btn" href="<?php echo e(route('admin.products.edit', $product)); ?>">Edit</a>
                            <form method="POST" action="<?php echo e(route('admin.products.destroy', $product)); ?>"><?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?><button class="btn btn-danger">Hapus/Nonaktif</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
        <div style="margin-top:16px"><?php echo e($products->links()); ?></div>
</div><?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-online-sales\resources\views/admin/products/index.blade.php ENDPATH**/ ?>