<?php $__env->startSection('title', 'Dashboard Admin'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <h1>Dashboard Admin Sementara</h1>
        <p>
            Selamat datang di halaman administrator.
            Fitur dashboard admin akan dikembangkan
            pada Milestone 7.
        </p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-online-sales\resources\views/admin/placeholder.blade.php ENDPATH**/ ?>