<?php $__env->startSection('title', $order->code); ?>
<?php $__env->startSection('content'); ?><h1>
        Detail Pesanan <?php echo e($order->code); ?></h1>
    <div class="card">
        <p>Status: <strong><?php echo e(strtoupper($order->status)); ?></strong>
        </p>
        <p>Penerima: <?php echo e($order->recipient_name); ?> | <?php echo e($order->phone); ?></p>
        <p>Alamat: <?php echo e($order->address); ?></p>
        <p>Pengiriman: <?php echo e($order->shipping_courier); ?> <?php echo e($order->shipping_service); ?> - <?php echo e($order->shipping_eta); ?></p>
    </div>
    <div class="table-scroll">
        <table>
            <thead>
                <tr>
                    <th>Produk</th>
                    <th>Harga</th>
                    <th>Jumlah</th>
                    <th>Subtotal</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->product_name); ?></td>
                        <td>Rp<?php echo e(number_format($item->price, 2, ',', '.')); ?></td>
                        <td><?php echo e($item->quantity); ?></td>
                        <td>Rp<?php echo e(number_format($item->subtotal, 2, ',', '.')); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <div class="card" style="margin-top:16px">
        <p>Subtotal: Rp<?php echo e(number_format($order->subtotal, 2, ',', '.')); ?></p>
        <p>Ongkir: Rp<?php echo e(number_format($order->shipping_cost, 2, ',', '.')); ?></p>
        <h3>Total: Rp<?php echo e(number_format($order->grand_total, 2, ',', '.')); ?></h3>
</div><?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-online-sales\resources\views/orders/show.blade.php ENDPATH**/ ?>