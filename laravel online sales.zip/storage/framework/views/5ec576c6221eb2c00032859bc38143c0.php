<?php $__env->startSection('title', 'Masuk'); ?>
<?php $__env->startSection('content'); ?><div class="card auth-card"><span class="eyebrow">SELAMAT DATANG KEMBALI</span>
        <h1>Masuk ke akunmu</h1>
        <p class="muted" style="text-align:left">Lanjutkan belanja dan pantau pesanan dengan mudah.</p>
        <form method="POST" action="<?php echo e(route('login.store')); ?>"><?php echo csrf_field(); ?><label>Email<input type="email" name="email"
                    value="<?php echo e(old('email')); ?>" autocomplete="username" required autofocus></label><label>Password<input
                    type="password" name="password" autocomplete="current-password" required></label><button
                class="btn">Masuk</button></form>
        <p class="muted" style="margin-top:20px">Belum punya akun? <a href="<?php echo e(route('register')); ?>"><strong>Daftar di
                    sini</strong></a></p>
</div><?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel online sales\resources\views/auth/login.blade.php ENDPATH**/ ?>