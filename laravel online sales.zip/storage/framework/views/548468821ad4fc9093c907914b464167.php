<?php $__env->startSection('title', 'Checkout'); ?>
<?php $__env->startSection('content'); ?><h1>
        Checkout</h1>
    <div class="checkout-layout">
        <div class="card">
            <form method="POST" action="<?php echo e(route('checkout.store')); ?>"><?php echo csrf_field(); ?><label>Nama Penerima<input class="input"
                        name="recipient_name" value="<?php echo e(old('recipient_name', auth()->user()->name)); ?>" required>
                </label>
                <label>No. Telepon<input class="input" name="phone" value="<?php echo e(old('phone')); ?>" required>
                </label>
                <label>Alamat
                    <textarea class="input" rows="4" name="address" required><?php echo e(old('address')); ?></textarea>
                </label>
                <label>Ekspedisi<select name="shipping_service_id" required>
                        <option value="">Pilih ekspedisi</option>
                        <?php $__currentLoopData = $shippingServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($service->id); ?>" data-cost="<?php echo e($service->cost); ?>"
                                <?php if(old('shipping_service_id') == $service->id): echo 'selected'; endif; ?>><?php echo e($service->courier); ?> - <?php echo e($service->service); ?>

                                (<?php echo e($service->eta); ?>) - Rp<?php echo e(number_format($service->cost, 2, ',', '.')); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </label>
                <button class="btn" <?php if($shippingServices->isEmpty()): echo 'disabled'; endif; ?>>Buat Pesanan</button>
                <?php if($shippingServices->isEmpty()): ?>
                    <p class="validation-error">Belum ada layanan pengiriman aktif. Hubungi admin sebelum checkout.</p>
                <?php endif; ?>
            </form>
        </div>
        <div class="card">
            <h3>Ringkasan</h3>
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p><?php echo e($item['product']->name); ?> x <?php echo e($item['quantity']); ?> =
                    Rp<?php echo e(number_format($item['lineTotal'], 2, ',', '.')); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <hr>
            <div data-subtotal="<?php echo e($subtotal); ?>"><strong>Subtotal Rp<?php echo e(number_format($subtotal, 2, ',', '.')); ?></strong>
            </div>
            <div class="summary-line"><span>Ongkos kirim</span><strong data-shipping-total>Pilih ekspedisi</strong></div>
            <div class="summary-total" data-order-total></div>
            <p class="muted">Ongkir ditambahkan sesuai ekspedisi yang dipilih.</p>
        </div>
</div><?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-online-sales\resources\views/checkout/index.blade.php ENDPATH**/ ?>