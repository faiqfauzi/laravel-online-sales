<?php $__env->startSection('title', $product->name); ?>
<?php $__env->startSection('content'); ?><div class="card">
        <div class="checkout-layout">
            <?php if($product->image): ?>
                <img class="thumb" style="height:340px" src="<?php echo e(asset('storage/' . $product->image)); ?>"
                alt="<?php echo e($product->name); ?>"><?php else: ?><div class="thumb" style="height:340px">
                </div>
            <?php endif; ?>
            <div>
                <div class="muted"><?php echo e($product->category->name); ?> | <?php echo e($product->sku); ?></div>
                <h1><?php echo e($product->name); ?></h1>
                <p><?php echo e($product->description); ?></p>
                <p class="price">Rp<?php echo e(number_format($product->price, 2, ',', '.')); ?></p>
                <p>Stok tersedia: <?php echo e($product->stock); ?></p><?php if(auth()->guard()->check()): ?> <?php if(auth()->user()->role === 'customer' && $product->stock > 0 && Route::has('cart.store')): ?>
                    <form method="POST" action="<?php echo e(route('cart.store', $product)); ?>"><?php echo csrf_field(); ?><label>Jumlah<input class="input"
                                style="max-width:120px" type="number" name="quantity" min="1"
                                max="<?php echo e($product->stock); ?>" value="1">
                        </label>
                        <button class="btn">Tambah ke Keranjang</button>
                    </form>
                <?php elseif($product->stock === 0): ?>
                    <p class="badge cancelled">Stok habis. Cek kembali nanti.</p>
            <?php endif; ?> <?php else: ?><p>
                    <a href="<?php echo e(route('login')); ?>">Login</a> untuk berbelanja.
            </p><?php endif; ?>
        </div>
    </div>
</div><?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-online-sales\resources\views/shop/show.blade.php ENDPATH**/ ?>